import {
    world,
    system,
    Player,
    Entity,
    ItemStack
} from '@minecraft/server'
import Storage from './database.js'
import convert from './Ar.js'
import {getLevels, getProgressPercentage} from "./level.js"
import {
    ModalFormData,
    ActionFormData,
    MessageFormData
} from "@minecraft/server-ui"
const currentPlayers = world.getPlayers(),
      teamsData = new Storage('teams.Data'),
      teamDataBase = new Storage('teamDataBase ?? ofAllTeams'),
      playerTeam = new Storage ('playerTeam'),
      soundsData = new Storage('soundsData ?? forAllPlayers'),
      alertsData = new Storage ("alerts ? Data with ( Date )"),
      AllPlayers = new Storage ('AllPlayers');

let creating = {}
let playersFlags = {}

system.beforeEvents.watchdogTerminate.subscribe(s => {
    s.cancel = true; 
})




let types = [['§o§bPUBLIC', '§4§oPRIVATE'], ['For all', 'Private']];

function createMsg (player, msg) {
    player.onScreenDisplay.setActionBar(`§f[§aTeams Add-on§f] - ${msg}`)
}


world.beforeEvents.playerInteractWithBlock.subscribe(i => {
    if ((i.player["cool_down"] ?? 0) > Date.now()) return;
    i.player["cool_down"] = Date.now() + 1000
    let itemStack = i.itemStack
    if (creating[i.player.name]) {
   system.run(() => {
       let {teamValue, teamDataValue, sI, key, color} = creating[i.player.name]
    
    let {x, y,z} = i.block.location
    
    if (itemStack?.typeId != "flaxon:flag") return
    let con = i.player.getComponent("inventory").container
    
    let entity = i.player.dimension.spawnEntity(`flaxon:flag_${color}`, {x: x + 0.5, y: y+1, z: z + 0.5})


    teamDataValue["entityLoc"] = {x, y: y+1, z}
    teamDataValue["entityDim"] = i.player.dimension.id
    
    teamsData.set(key, teamValue)
    teamDataBase.set(key, teamDataValue)
    playerTeam.set(teamValue.owner, { name: teamValue.name, key: key, selectedEffect: null })
    createMsg(i.player, `§adone created team! §d"${convert(teamValue.name)}"`)
    entity.addTag("key:"+ teamValue.key) 
    i.player.runCommand(`setblock ${x} ${y} ${z} bedrock`)
    con.setItem(i.player.selectedSlotIndex, new ItemStack("flaxon:teams"))
    delete creating[i.player.name]
   })
    }
})

function getVectors(loc, maxDistance) {
    let result = [];
    let { x, y, z } = loc;

    for (let i = 0; i <= maxDistance; i++) {
        result.push({ x: x + i, y, z });
    }


    for (let i = 0; i <= maxDistance; i++) {
        result.push({ x: x - i, y, z });
    }


    for (let i = 0; i <= maxDistance; i++) {
        result.push({ x, y, z: z + i });
    }


    for (let i = 0; i <= maxDistance; i++) {
        result.push({ x, y, z: z - i });
    }

    return result;
}


system.runInterval(() => {
    teamsData.all().forEach(team => {
        let dataBase = teamDataBase.get(team.key)
        if (!dataBase) return
        let entityLoc = dataBase.entityLoc
        if (!entityLoc) return
        let maxDistance = dataBase.distance
        let locs = getVectors(entityLoc, maxDistance)
        
        for (let VeC of locs) {
            world.getDimension(dataBase.entityDim).spawnParticle("minecraft:balloon_gas_particle", {x: VeC.x + 0.5, y: VeC.y, z: VeC.z + 0.5})
        }
        let entity_flag = world.getDimension(dataBase.entityDim).getEntitiesAtBlockLocation(dataBase.entityLoc)
        if (!entity_flag) return

        entity_flag.forEach(e =>{
            let {inUpgradeMode}=dataBase
            
            let shortcut = ''
            if (inUpgradeMode) {
                let {elapsedTime, totalTime} = inUpgradeMode
                let time = getProgressPercentage(elapsedTime, totalTime)
                let color = '§c'
                if (time <= 50) {
                    color = "§a"
                }
                shortcut = `\n${color}%${time}`
            }
            
            if(e.typeId.startsWith("flaxon:flag_")) {
                e.nameTag=`§bname: §l${team.color}${convert(team.name)}§r \n§ePoints: §c${dataBase.points}\n§eLevel: §p${dataBase.level}${e.hasTag("notExist")?"\n§cThe flag has Teken!":""}${shortcut}`
            }
        })
    })
}, 5)



world.afterEvents.playerInteractWithEntity.subscribe(a => {
    const {player, target, itemStack} = a
    if (target.typeId.startsWith("flaxon:flag_")) {
        if (playerTeam.has(player.name)) {
            let {name, key} = playerTeam.get(player.name)
            let targetKey = target.getTags().find(tG => tG.startsWith("key:"))?.split(":")[1]
            if (targetKey == key) {
                if (itemStack?.typeId == "flaxon:flag" && playersFlags[player.name]) {
    let { key, teamKey, run } = playersFlags[player.name];
    
    
    let team_1 = teamDataBase.get(key);
    let team_2 = teamDataBase.get(teamKey);
    if (team_2.inUpgradeMode){
        player.onScreenDisplay.setActionBar("§cthe Flag is under maintenance.")
        return;
    }
    system.clearRun(run);
    let entities = world.getDimension(team_1.entityDim).getEntitiesAtBlockLocation(team_1.entityLoc);
    let enti;
    
    for (let en of entities) {
        if (en.typeId.startsWith("flaxon:flag_")) {
            system.run(() => en.removeTag("notExist"));
            enti = en;
        }
    }
    
    teamDataBase.update(teamKey, value => {
        value.points += 100;
        return value;
    });
    
    teamDataBase.update(key, value => {
        value.points = value.points >= 100 ? value.points - 100 : 0;
        
        
        
        
        let points = value.points
        let level = value.level
        let allLevels = getLevels()
        if (allLevels[level]){
            let levelPoints = allLevels[level].points
            if (points < levelPoints[0]) {
                
                value.distance = allLevels[value.level].distance
                value.e_distance = allLevels[value.level].e_distance
                value.e_power = allLevels[value.level].e_power
                value.effects = value.effects.filter(
                    (r) => r != allLevels[value.level].awards[0]
                )
                allLevels[level].enemyEffect.forEach(ef=>{
                    value.enemyEffects = value.enemyEffects.filter(s => s != ef)
                });
                value.level -= 1
            }
        }
        return value;
    });
    
    let currentPoints = teamDataBase.get(teamKey)?.points;
    let levels = getLevels();
    let newLevel = null;
    
    for (let level in levels) {
        let pointsRange = levels[level].points;
        if (currentPoints >= pointsRange[0] && currentPoints < pointsRange[1] && team_2?.level != level) {
            newLevel = { level, ...levels[level] };
            break;
        }
    }
    if (newLevel) {
        let timeLeft = newLevel.time 
        let intervalId = system.runInterval(function (){
            if (timeLeft > 0) {
            timeLeft -= 1000;
            teamDataBase.update(teamKey, v => {
                    v.inUpgradeMode = {
                        totalTime: newLevel.time,
                        timeLeft,
                        elapsedTime: newLevel.time - timeLeft,
                        level: newLevel.level
                    };
                    return v;
                })
        } else {
            world.getDimension(team_2.entityDim).spawnParticle("minecraft:totem_particle", team_2.entityLoc)
            world.playSound('random.levelup', team_2.entityLoc)
            teamDataBase.update(teamKey, vs =>{
                vs.level = newLevel.level;
                vs.distance = newLevel.distance;
                vs.inUpgradeMode = null;
                
                newLevel.awards.forEach(aw =>{
                    if (!vs.effects.includes(aw)){
                        vs.effects.push(aw)
                    }
                })
                vs.e_power = newLevel.e_power
                vs.e_distance = newLevel.e_distance
                vs.points += 15
                
                newLevel.enemyEffect.forEach(eff => {
                    if (!vs.enemyEffects.includes(eff)) {
                        vs.enemyEffects.push(eff)
                    }
                })
                return vs;
             });
             system.clearRun(intervalId)
           }
        }, 20)
        
    }
    player.playSound("random.levelup");
    let { container } = player.getComponent("inventory");
    container.setItem(player.selectedSlotIndex, undefined);
    delete playersFlags[player.name];
} else {
    openTeamMenu(player, teamsData.get(key));
}
            } else {
                if (teamDataBase.get(targetKey).inUpgradeMode) {
                    player.onScreenDisplay.setActionBar("§cthe Flag is under maintenance.")
                    return;
                }
                if (playersFlags[player.name]){
                    player.onScreenDisplay.setActionBar("§cyou teken another flag!.")
                    return
                }
                if (target.hasTag("notExist")) {
                    player.onScreenDisplay.setActionBar("§cthe flag is aleardy teken.")
                }else{
                    let {container} = player.getComponent("inventory")
                    if (!hasSpaceForIt(container)) {
                        player.onScreenDisplay.setActionBar("§cyou need space in your inventory.")
                        return;
                    }
                    let itemFlag = new ItemStack("flaxon:flag")
                    container.addItem(itemFlag)
                    let r = system.runInterval(() => {
                        player.onScreenDisplay.setActionBar("§ago to your team as soon as possible!")
                        player.addEffect("slowness", 5, { amplifier: 2, showParticles: false})
                    }, 2)
                    playersFlags[player.name] = {key: targetKey, teamKey: key, run: r}
                    target.addTag("notExist")
                }
            }
        } else {
            openInformationTeam(player, target)
        }
    }
})

function openInformationTeam (player, en){
    let key = en.getTags()?.find(tG => tG.startsWith("key:"))?.split(":")[1]
    if (!key) return
    let team = teamsData.get(key)
    let teamDt = teamDataBase.get(key)
    if (team.type=="Private"){
        createMsg(player, "§cThe team is priavte!");
        return
    }
    let form = new ActionFormData()
    .title(team.color+team.name)
    .body(`§i§l-§r §8Owner§r - §2§l${team.owner}\n§r§i§l-§r §8Name§r - ${team.color}${team.name}\n§i§l-§r §8Players§r - ${team.color}${teamDataBase.get(team.key).players.length}\n§i§l-§r §8Discription§r - ${team.color}${team.description}`)
    .button("§1JOIN\n§3§o> Here <", 'textures/ui/icon_blackfriday.png')
    .show(player)
    .then(r =>{
        if(r.canceled)return
        if (r.selection == 0) hasJoined(player, team)
    })
}

function showRank (player, teamA) {
    let form = new ActionFormData();
    let teams = teamsData.all();
    let teamPoints = teamDataBase.all();
    let shortcut = (te) => te.name == teamA.name ? " - §ayour team" : ''

    let teamsWithPoints = teams.map((team, index) => ({
        name: team.name,
        points: teamPoints[index].points
    }));

    teamsWithPoints.sort((a, b) => b.points - a.points);

    let resultString = teamsWithPoints.map((team, index) => 
        `§d§l§o${index + 1}§r - §b${team.name}§r : §o§e${team.points}${shortcut(team)}`
    ).join("\n");
    if (resultString !=''){
        resultString+="\n\n"
    }

    form
     .title("§o§r[ SHOW RANK ]")
     .body(resultString || "§cNo Teams in World!\n\n")
     .button("§r§o[ §4CLOSE§r§o ]\n§3> Here <", "textures/ui/cancel.png")
     .show(player)
     .then( r => {
         if (r.canceled) return;
         if (r.selection == 0) openTeamMenu(player, teamA);
     });
}

function openTeamMenu (player, team) {
    let form = new ActionFormData();
    form
    .title(team.color + team.name)
    .body(`§athis form for "${team.color+team.name}§a" team,\n\n§i§l-§r §8Owner§r - §2§l${team.owner}\n§r§i§l-§r §8Name§r - ${team.color}${team.name}\n§i§l-§r §8Players§r - ${team.color}${teamDataBase.get(team.key).players.length}\n§i§l-§r §8Discription§r - ${team.color}${team.description}`
    )
    .button("§2EFFECT\n§3§o> Here <", "textures/ui/achievements.png")
    .button("§8SHOW RANK\n§3§o> Here <", "textures/ui/absorption_effect.png")
    .button("§cEXIT\n§3§o> Here <", "textures/ui/cancel.png")
    if (team.owner == player.name && teamDataBase.get(team.key).enemyEffects.length != 0) {
        form.button("§aSELECTE ENEMY EFFECT\n§3§o> Here <", "textures/ui/icon_recipe_equipment.png")
    }
    form
    .show(player)
    .then( function (r) {
        if (r.canceled) return
        if (r.selection == 0) selecteEffect(player, team)
        if (r.selection == 1) showRank(player, team)
        if (r.selection == 3) selecteEnemyEffect(player, team)
    } )
}

function selecteEffect (player, team) {
    let teamDt = teamDataBase.get(team.key)
    let form = new ActionFormData()
     .title(team.color+team.name+" §dEffects")
     .body(teamDt.effects.length!=0?`§aSelecte Your effect`:'§cYour team does not open any effect!')
     teamDt.effects.forEach(eff =>{
         let playerEffect = playerTeam.get(player.name).selectedEffect
         form.button(`${eff.toUpperCase().replace(/_/g, " ")}\n${playerEffect == eff ? "§2§oselected" : "§3§o> Here <"}`, `textures/gui/newgui/mob_effects/${eff}_effect.png`)
     })
     
     form
     .button("§cCLOSE\n§r§3§o> Here <", "textures/ui/cancel.png")
     .show(player)
     .then (s =>{
         if (s.canceled) return
         if (s.canceled == teamDt.effects.length) {
             openTeamMenu(player, team)
         }else{
             let newEff = teamDt.effects[s.selection]
             if (newEff){
                 playerTeam.update(player.name,a=>{
                     a.selectedEffect = newEff;
                     return a;
                 })
             }
         }
     })
}

function selecteEnemyEffect (player, team) {
    let teamDt = teamDataBase.get(team.key);
    let form = new ActionFormData()
    .title("Selecte Team Effect")
    .body("Selecte Team Effect!?")
    teamDt.enemyEffects.forEach( r=> {
        form.button(`${r.toUpperCase().replace(/_/g, ' ')}\n${teamDt.selectedEnemyEffect == r ? "§2§oselected" : "§3§o> Here <"}`, `textures/gui/newgui/mob_effects/${r}_effect.png`)
    })
    form
    .show(player)
    .then ( a => {
        if (a.canceled) return
        let selEff = teamDt.enemyEffects[a.selection]
        if (!selEff) return
        teamDataBase.update(team.key, s=> {
            s.selectedEnemyEffect = selEff
            return s
        })
    })
}

world.afterEvents.entityDie.subscribe(i =>{
    system.run(function () {
    if (i.deadEntity.typeId =="minecraft:player"&&playersFlags[i.deadEntity.name]){
        let killer = i.damageSource.damagingEntity
        let {key, teamKey, run} = playersFlags[i.deadEntity.name]
        
        
        
        let i_1 = teamDataBase.get(key)
        let entities = world.getDimension(i_1.entityDim).getEntitiesAtBlockLocation(i_1.entityLoc)
        system.clearRun(run)
        for (let i of entities){
            if(i.typeId.startsWith("flaxon:flag_")){
                if(i.hasTag("notExist"))system.run(() => i.removeTag("notExist"))
            }
        }


        if (killer instanceof Player) {
            let te_db = teamDataBase.get(teamKey)
            if (te_db.players.includes(killer.name)){
            teamDataBase.update(teamKey, v => {
                v.points += 25
                return v
            })
            }
        }
        
        
        let {container} = i.deadEntity.getComponent("inventory")
        for (let i = 0; i < container.size; i++) {
            let item = container.getItem(i)
            if (item && item.typeId == "flaxon:flag") {
                container.setItem(i, undefined)
            }
        }
        delete playersFlags[i.deadEntity.name]
    }
})
})

world.afterEvents.playerLeave.subscribe(({ playerName }) => {
    if (playersFlags[playerName]) {
        let team = teamsData.get(playersFlags[playerName].key)
        let teamData = teamDataBase.get(team.key)
        system.clearRun(playersFlags[playerName].run)
        let entities = world.getDimension(teamData.entityDim).getEntitiesAtBlockLocation(teamData.entityLoc)
        for (let en of entities){
            if (en.typeId.startsWith("flaxon:flag_")) system.run(()=>en.removeTag("notExist"))
        }
        delete playersFlags[playerName]
    }
})

function hasSpaceForIt (container) {
    for (let i = 0; i < container.size; i++) {
        let item = container.getItem(i)
        if (!item) {
            return true
        }
    }
    return false
}

world.afterEvents.playerSpawn.subscribe((data) => {
    let { player, initialSpawn } = data
    if (!initialSpawn) return
    defaultSounds(player)
    let date = new Date().toLocaleString()
    let alert = {
        BY: 'World ( SYSTEM )',
        MSG: `You have Joined To server in date (${date})`, 
        TYPE: 'Join', 
        team: null, 
        date: date
    }


    if (!alertsData.has(player.name)){
   alertsData.set(player.name, { name: player.name, alerts: [alert] })
    }

    if (!AllPlayers.has(player.name)) {
        AllPlayers.set(player.name, { name: player.name, date })
    }
    
    if (!pInventory(player).map(p => p.typeId).includes("flaxon:teams")) {
    player.runCommandAsync('give @s flaxon:teams 1 0 {"item_lock":{"mode":"lock_in_inventory"}}')
    }
})
function pInventory (p) {
    const inv = p.getComponent("inventory").container;
    const its = []
    
    for (let i=0;i<inv.size;i++){
        const it=inv.getItem(i)
        if(it){
            its.push(it);
        }
    }
    return its;
}

world.afterEvents.itemUse.subscribe((data) => {
    let { source, itemStack } = data

    if (itemStack.typeId == 'flaxon:teams') {
        GeneralMenu(source)
    }
})


function Effect (player) {
    player.runCommandAsync(
        `particle minecraft:totem_particle ~ ~ ~`
    )
    player.runCommandAsync(
        `particle minecraft:totem_particle ~1 ~ ~`
    )
    player.runCommandAsync(
        `particle minecraft:totem_particle ~ ~ ~1`
    )
}



function GeneralMenu (player) {
    const form = new ActionFormData()
         .title('Main Form')
         .body(
             `§i§l-§r §2§lGeneral Menu§r\n§b§lThis Mod Genereted By §r§o§f[ RIDA, MAHMOOD ]\n§r§lYou§4Tube§r - §2§l@Flaxon3AR`
             )
         .button("§r§o[ §2§lAll Teams§r §o]\n§r§3§o > Here <", 
         "textures/ui/sidebar_icons/capes.png")
         .button("§r§o[ §0§lSettings§r §o]\n§r§3§o > Here <",
         "textures/ui/icon_setting.png")
         .button("§r§o[ §b§lCreate Team§r §o]\n§r§3§o > Here <",
         "textures/ui/recipe_book_icon.png")
         .button("§r§o[ §q§lMY Alerts§r§o ]\n§r§3§o> Here <",
         'textures/ui/Feedback.png')
         .button("§r§o[ §n§lTEAMS LIST§r§o ]\n§r§3§o> Here <", "textures/ui/absorption_effect.png")

         let isAdmin = player.hasTag('AdminOfWorld')

         if(playerTeam.has(player.name)) {
             form.button("§r§o[ §6§lMY TEAM§r§o ]\n§r§3§o > Here <",
             "textures/ui/icon_blackfriday.png")
         }

         form.show(player).then(({ canceled, selection }) => {
             if(canceled)return


             switch(selection){
                 case 0:
                     showAllTeams(player)
                     break
                 case 1:
                     ModSettings(player)
                     break
                 case 2:
                     CreatNewTeam (player)
                     break
                 case 3:
                     MYAlerts(player)
                     break
                 case 4:
                     TeamsList(player)
                     break
                 case 5:
                     if (playerTeam.has(player.name)){
                         NowMyTeam(player)
                     }
                     break
             }
         })
}

function CreatNewTeam (player) {
    let FormBody = playerTeam.has(player.name) ? "§cYou have joined to team can't create new team" : "Add Team name and color and type§2< Enjoy (: >"
    const colors = {
       CODES: ["§e", "§0", "§d", "§6", "§2", "§a", "§1", "§c", "§n"],
       values: ["§o§eYELLOW",
                "§o§0BLACK",
                "§o§dPINK",
                "§o§6ORANGE",
                "§o§2GREEN",
                "§o§aLIME",
                "§1§oBLUE",
                "§c§oRED",
                "§o§nBROWN"]
    }
    if (creating[player.name]) {
        createMsg(player, "§cYou can't open the creating form because you in creating mode")
        return
    }

    let form = new ModalFormData()
            .title('§o§f[ Add Team Form ]')
            .textField(FormBody + '\n\n§e§lTeam §r§r§o[ Name ]',"")
            .textField('§e§lTeam §r§r§o[ Members Limit ]', '')
            .textField('§e§lTeam §r§r§o[ Description ]',"")
            .dropdown('§e§lTeam §r§r§o[ type ]', types[0], 0)
            .dropdown('§e§lTeam §r§r§o[ Color ]', colors.values, 0)
            //.textField(" owner", '')
            .show(player)
            .then(({ canceled, formValues })=>{
                if(canceled)return

                const [name, limit, description, type, color] = formValues
                
                if (
                    name == '' ||
                    limit == '') {
                        createMsg(player, '§cThe values can not be an empty.')
                        return
                    }

                if (isNaN(limit)) {
                    createMsg(player, '§cThe limit should be a number')
                    return
                }

                if (playerTeam.has(player.name)) {
                    createMsg(player, '§cYou have joined to team!!')
                    return
                }
                let Ids = newKeyOfTeams()

                let teamValue = {
                    name: convert(name),
                    color: colors.CODES[color],
                    colorText: colors.values[color],
                    owner: player.name,
                    type: types[1][type],
                    key: Ids[0],
                    limit: parseInt(limit),
                    description: convert(
                        description || '§cWithout description')
                }
                let teamDataValue = {
                    players: [player.name], 
                    points: 0,
                    level: 1,
                    distance: 5
                    , inUpgradeMode: null,
                    effects: [],
                    e_distance: 0,
                    e_power: 0,
                    enemyEffects: [],
                    selectedEnemyEffect: null
                }
                creating[player.name] = {teamDataValue, teamValue, key: Ids[0], color: teamValue.colorText.slice(4).toLowerCase()};
                let {container} = player.getComponent("inventory")
                let item_flag = container.setItem(player.selectedSlotIndex, new ItemStack("flaxon:flag"))

                PLAYSOUND('Create', player)
            })
}

function newKeyOfTeams () {
    let ids = [],
        id = ''
    do {
        id = ''
        for (let i = 0; i < 10; i++) {
           id += Math.floor(Math.random() * 10)
        }
    } while (teamsData.has(id) || ids.includes(id))
    
    ids.push(id)
    
    return ids
}

function showAllTeams (player) {
    let formBody = teamsData.size() == 0 ? '§c§oThere are no teams in this world/server try agin': "§achose team to show info to this team"
    
    let form = new ActionFormData()
           .title('§o§f[ All Teams ]')
           .body(formBody)
           
           teamsData.all().forEach((team) => {
               form.button(`§r§o[ ${team.color + team.name}§r§o ]\n[ ${team.type} ]`, 'textures/ui/worldsIcon.png')
           })
           form
              .button('§r§o[ §c§lExit§r§o ]\n§r§3§o> Here <','textures/ui/cancel.png')
              .show(player).then(({ canceled, selection })=>{
                  if(canceled)return
                  
                  if(selection == teamsData.size()) {
                      GeneralMenu(player)
                  }else{
                      let teamSelected = teamsData.all()[selection]
                      
                      if (teamSelected !== undefined) {
                          let team = teamSelected
                          
                          if (team.type == 'Private' && !player.hasTag('AdminOfWorld')) {
                              createMsg(player, '§cCan not open this team because this team type is private.')
                              return
                          }
                          
                          let form1 = new ActionFormData()
                                 .title(`§r§o[ ${team.color}${team.name}§r§o ]`)
                                 .body(`§i§l-§r §8Owner§r - §2§l${team.owner}\n§r§i§l-§r §8Name§r - ${team.color}${team.name}\n§i§l-§r §8Players§r - ${team.color}${teamDataBase.get(team.key).players.length}\n§i§l-§r §8Discription§r - ${team.color}${team.description}`)
                                 .button('§r§o[ §1§lJOIN§r§o ]\n§r§3§o > Here <', 'textures/ui/icon_blackfriday.png')
                                 if (player.hasTag('AdminOfWorld')){
                                     form1.button('§r§o[ §0§lDelete §r§o]\n§r§3§o > Here <','textures/ui/icon_trash.png')
                                 }
                                 form1
                                 .button('§r§o[ §c§lExit§r§o ]\n§r§3§o > Here <',"textures/ui/cancel.png")
                                 .show(player).then(r => {
                                     if (r.canceled) return
                                     
                                     switch(r.selection){
                                         case 0:
                                             hasJoined(player, team)
                                             break
                                         case 1:
                                             if (player.hasTag('AdminOfWorld')){
                                                 deleteTeam(team)
                                             }else GeneralMenu(player)
                                             break
                                         case 2:
                                             GeneralMenu(player)
                                             break
                                        
                                     }
                                 })
                      }
                  }
              })
}

function hasJoined (player, team) {
    if (playerTeam.has(player.name)) {
        createMsg(player, '§cYou have joined to another team.')
        return
    }
    let teamPlayers = teamDataBase.get(team.key).players
    
    if (team.limit <= teamPlayers.length) {
        createMsg(player, '§cthe Team is full members.')
        return
    }
    
    teamDataBase.update(team.key, (value) => {
        let newValue = value
        
        newValue.players.push(player.name)
        
        return newValue
    })
    playerTeam.set(player.name, { name: team.name, key: team.key, selectedEffect: null })
    createMsg(player, '§aYou have now withtin members to this team.')
    PLAYSOUND('Join', player)
}

function NowMyTeam (player) {
    let playerTeamInNow = playerTeam.get(player.name)
    let team = teamsData.get(playerTeamInNow.key)
    let playersOfTeam = teamDataBase.get(team.key).players
    let form = new ActionFormData()
        .title(`§o§f[ ${team.color}${team.name}§r§o§f ]`)
        .body(`§i§l-§r §8Name§r - ${team.color}${team.name}\n§i§l-§r §8Members§r - ${team.color}${playersOfTeam.length}\n§i§l-§r §8Owner§r - ${team.color}${team.owner}\n§i§l-§r §8Limit§r - ${team.color}${team.limit}\n§i§l-§r §8Members With name§r : §r§f[${playersOfTeam.join(", ")}]`)
        .button('§r§o[ §0§lExit From Team§r§o ]\n§r§3§o> Here <',
        'textures/ui/icon_trash.png')
        .button('§r§o[ §c§lExit §r§o]\n§r§3§o> Here <','textures/ui/cancel.png')
        
        let isOwner = team.owner == player.name
        
        if (isOwner) {
            form.button(
                '§r§o[ §e§lManagement§r§o ]\n§r§3§o> Here <',
                'textures/ui/op.png'
            )
        }
      form
        .show(player).then(({ canceled, selection })=>{
            if (canceled)return
            if (selection == 1) GeneralMenu(player)
            if (selection == 0) {
                if (playersFlags[player.name]){
                    createMsg(player, "§cCan't exit from team because you teken flag of another team.")
                    return
                }
                if (team.owner == player.name && playersOfTeam[1]){
                    teamsData.update(team.key, (oldTeamValue) => {
                        let newTeamValue = oldTeamValue
                        
                        newTeamValue.owner = playersOfTeam[1]
                        return newTeamValue
                    })
                }
                teamDataBase.update(team.key, (value) => {
                    let newValue = value
                    let index = playersOfTeam.indexOf(player.name)
                    if (index !== -1) {
                        newValue.players.splice(index, 1)
                    } else console.error(index)
                    
                    
                    return newValue
                })
                playerTeam.delete(player.name)
                PLAYSOUND('Edit', player)
            }
           if (selection == 2) {
               MYTEAM(player,team)
           }
        })
}

function deleteTeam (team) {
    let players = teamDataBase.get(team.key).players
    
    players.forEach((player) => {
        playerTeam.delete(player)
    })
    
    teamsData.delete(team.key)
    teamDataBase.delete(team.key)
}

function defaultSounds (src) {
    let srcName = src.name
    if (!soundsData.has(srcName)){
         let Edit = `${srcName}|Edit`,
             Join = `${srcName}|Join`,
             Create = `${srcName}|Create`,
             error = `${srcName}|Error`
        soundsData.set(Edit, 'random.levelup')
        soundsData.set(Join, 'random.anvil_land')
        soundsData.set(Create, 'random.levelup')
        soundsData.set(error, 'random.break')
        soundsData.set(srcName, 'forCoolDown')
    }
}

function PLAYSOUND (src, player) {
    if (soundsData.has(player.name)) {
        let sound = soundsData.get(`${player.name}|${src}`)
        
        player.playSound(sound)
    }
}

function ModSettings (player) {
    if (!soundsData.has(player.name)) return
    let Edit = soundsData.get(`${player.name}|Edit`),
        Join = soundsData.get(`${player.name}|Join`),
        error = soundsData.get(`${player.name}|Error`),
        Create = soundsData.get(`${player.name}|Create`)
    
    let form = new ModalFormData()
        .title('§o§f[ §0§lSettings§r§o§f ]')
        .textField('§e§lSound §r§o§f[ Create ]','',Create)
        .textField('§e§lSound §r§o§f[ Edit ]','',Edit)
        .textField('§e§lSound §r§o§f[ Join ]','',Join)
        .textField('§e§lSound §r§o§f[ Error ]','',error)
        .show(player).then(r=>{
            if(r.canceled)return
            
            const [v1,v2,v3,v4] = r.formValues
            
            change (player, 'Edit', v2)
            change (player, 'Error', v4)
            change (player, 'Join', v3)
            change (player, 'Create', v1)
            PLAYSOUND("Edit", player)
        })
}

function change (player, src, value) {
    if (soundsData.has(player.name)){
        soundsData.set(`${player.name}|${src}`, value)
    }
}

world.beforeEvents.chatSend.subscribe(r=>{
    let{sender,message}=r
    
    if(playerTeam.has(sender.name)){
        r.cancel=true
        let{name}=teamsData.get(playerTeam.get(sender.name).key)
        world.sendMessage(
            `<${sender.name}, ${convert(name)}> ${convert(message)}`
            )
    }else{
        world.sendMessage(
            `<${sender.name}> ${convert(message)}`
            )
        r.cancel=true
    }
})

/*function AdminPanel (admin) {
    let admin_menu = new ActionFormData()
          .title("§o§f[ Admin Panel ]")
          .body(`§e§l[ Admin panel ]\n\n§r§aChose Button\n§b§lThis Mod Genereted By §r§o§f[ RIDA, MAHMOOD ]`)
          .button('§r§o[ §e§lSet Admin§r§o ]\n§r§3§o> Here <', "textures/ui/icon_saleribbon.png")
          .button("§r§o[ §4§lClear All Teams§r§o ]\n§r§3§o> Here <",
          "textures/ui/icon_trash.png")
          .button("§r§o[ §b§lCreators§r§o ]\n§r§3§o> Here <",
          'textures/ui/accessibility_glyph_color.png')
          .show(admin).then(r=>{
              if(r.canceled)return
              
              switch(r.selection){
                  case 0:
                      SetAdmin(admin)
                      break
                  case 1:
                      teamsData.clear()
                      teamDataBase.clear()
                      playerTeam.clear()
                      break
                  case 2: 
                      creatorInfo(player)
                      break
              }
          })
}*/

function MYTEAM (player, team) {
    let MY = new ActionFormData()
         .title(team.color + team.name)
         .body('§f§o[§e!§f]§r - §b§lYou can Management Your Team')
         .button('§r§o[ §e§lAdd Member§r§o ]\n§r§3§o> Here <',
         "textures/ui/color_plus.png")
         .button('§r§o[ §4§lRemove Membrs§r ]\n§r§3§o> Here <',
         "textures/ui/ImpulseSquare.png")
         .button("§r§o[ §a§lEdit Limit§r§o ]\n§r§3§o> Here <",
         "textures/ui/icon_book_writable.png")
         .button("§r§o[ §b§lEdit Type§r§o ]\n§r§3§o> Here <",
         "textures/ui/icon_blackfriday.png")
         .button("§r§o[ §q§lEdit Name§r§o ]\n§r§3§o> Here <",
         "textures/ui/mashup_PaintBrush.png")
         .button("§r§o[ §1§lEdit Description§r§o ]\n§r§3§o> Here <",
         "textures/ui/inventory_icon.png")
         .button("§r§o[ §c§lDelete§r§o ]\n§r§3§o> Here <", "textures/ui/icon_trash.png")
         .show(player).then(r=>{
             if(r.canceled)return
             
             switch(r.selection){
                 case 0:
                     EditTeam(player, 'Add', team)
                     break
                 case 1:
                     EditTeam(player, 'Remove', team)
                     break
                 case 2:
                     EditTeam(player, 'limit', team)
                     break
                 case 3:
                     EditTeam(player, 'type', team)
                     break
                 case 4:
                     EditTeam(player, 'Name', team)
                     break
                 case 5:
                     EditTeam(player, 'Description', team)
                     break
                 case 6:
                     let team_d = teamDataBase.get(team.key)
                     let entity_flag = world.getDimension(team_d.entityDim).getEntitiesAtBlockLocation(team_d.entityLoc)
                     let {x, y, z} = team_d.entityLoc
                     player.runCommand(`setblock ${x} ${y - 1} ${z} air`)
                     entity_flag.forEach(e =>{
                         if(e.typeId.startsWith("flaxon:flag_")){ 
                             e.nameTag = ''
                             e.teleport({ x: 0, y: -65, z: 0})
                             system.runTimeout(() => e.kill(), 10)
                         }
                     })
                     deleteTeam(team)
                     break
             }
         })
}

function EditTeam (player, menu, team) {
    switch (menu) {
        case 'Add':
            const form1 = new ActionFormData()
                  .title('> §e§lAdd Member§r <')
                  .body("§i§l-§r §qChose Player To Add Yo your ( team )")
                  
                  AllPlayers.all().forEach((p)=>{
                      form1.button(`§r§o[ §b§l${p.name}§r§o ]\n§r§3§o> Here <`, 'textures/ui/worldsIcon.png')
                  })
                  
                  form1.show(player).then(r=>{
                      if (r.canceled)return
                      
                      const plr = AllPlayers.all()[r.selection]
                      
                      
                          hasJoined1(player, team, plr)
                          
                  })
            break
        case 'Remove':
            let players = teamDataBase.get(team.key).players
            let form2 = new ActionFormData()
                  .title('> §4§lRemove§r <')
                  .body('§f§o[§e!§f]§r - §4§lChose Player to remove')
                  
                  players.forEach(r=>{
                      form2.button(`§r§o[ §b§l${r}§r§o ]\n§r§3§o> Here <`,'textures/ui/icon_steve.png')
                  })
                  
                  form2.show(player).then(i=>{
                      if (i.canceled) return
                      
                      if (players[i.selection] == player.name){
                          createMsg(player, '§ccan not remove yourself!.')
                          return
                      }
                      teamDataBase.update(team.key, (value)=>{
                          let newValue = value
                          
                          newValue.players.splice(i.selection, 1)
                          
                          return newValue
                      })
                      alertsData.update(players[i.selection], (value) => {
                           let newValue = value
        
                           newValue.alerts.push({
                               BY: player.name,
    MSG: `You have Kicked From ( ${team.color + team.name}§r )`,
                               TYPE: 'Kick',
                              team,
                              date: new Date().toLocaleString() })
                           return newValue
                        })
                    
                    playerTeam.delete(players[i.selection])
                    PLAYSOUND('Edit', player)
                  })
            break
        case 'limit':
            let limitData = new ModalFormData()
                         .title(team.color + team.name)
                         .textField("Enter new Limit", `The limit is ( ${team.limit} )`, `${team.limit}`)
                         .show(player).then(c=>{
                             if(c.canceled)return
                             
                             const[newLimit]=c.formValues
                             if (isNaN(newLimit) || newLimit == ''){
                                 createMsg(player,
                                     '§cthe limit should be a number'
                                )
                                 return
                             }
                             teamsData.update(team.key, (value) => {
                                 let newValue = value
                                 
                                newValue.limit = parseInt(newLimit)
                                return newValue
                             })
                             
                             PLAYSOUND('Edit', player)
                         })
            break
        case 'Name':
            let nameData = new ModalFormData()
                 .title(team.color + team.name)
                 .textField('Enter New Name', `The old name is ( ${team.name} )`, team.name)
                 .show(player).then(t=>{
                     if(t.canceled)return
                     
                     const[newName]=t.formValues
                     
                     if (newName == ''){
                         createMsg(player, "§cthe name can't be an empty.")
                         return
                     }
                     
                     teamsData.update(team.key, (value) => {
                         let newValue = value
                         
                         newValue.name = convert(newName)
                         
                         return newValue
                     })
                     PLAYSOUND('Edit', player)
                 })
             break
        case "Description":
            let desData = new ModalFormData()
                .title(team.color + team.description)
                .textField('Enter new Description','',team.description)
                .show(player).then(l=>{
                    if (l.canceled) return
                    
                    let [des] = l.formValues
                    
                    if (des == '') {
                        createMsg(player, '§cthe description can not be a empty!!')
                        return
                    }
                    
                    teamsData.update(team.key, (value) => {
                        let newValue = value
                        
                        newValue.description = convert(des || '§cWithout description')
                        
                        return newValue
                    })
                    PLAYSOUND("Edit", player)
                })
            break
        case 'type':
            let typeData = new ModalFormData()
                   .title(team.color + team.type)
                   .dropdown('new Type', types[0], 0)
                   .show(player).then(x => {
                       if (x.canceled) return
                       
                       const [type] = x.formValues
                       
                       teamsData.update(team.key, (value) => {
                        let newValue = value
                        
                        newValue.type = types[1][type]
                        
                        return newValue
                    })
                    PLAYSOUND("Edit", player)
                   })
            break
    }
}

function hasJoined1 (player, team, plr) {
    if (playerTeam.has(plr.name)) {
        createMsg(player, '§cThe player has joined to another team.')
        return
    }
    let teamPlayers = teamDataBase.get(team.key).players
    
    if (team.limit <= teamPlayers.length) {
        createMsg(player, '§cTeam is full members.')
        return
    }
    
    alertsData.update(plr.name, (value) => {
        let newValue = value
        
        newValue.alerts.push({ BY: player.name, MSG: `Inviate To Team ( ${team.color + team.name}§r )`, TYPE: 'Inviate', team, date: new Date().toLocaleString() })
        return newValue
    })
    PLAYSOUND('Join', player)
}

function MYAlerts (player) {
    let myAlerts = alertsData.get(player.name).alerts
    let formBody = myAlerts.length == 0 ? '§o§f[§e!§f]§r - §b§lYou do not have any alert': '§o§f[§e!§f]§r - §b§lChose alert to show to you'
    let form = new ActionFormData()
           .title('§o§f[ Alerts ]')
           .body(formBody)
           
           myAlerts.forEach((alert)=>{
               form.button(`§r§o[ §b§l${alert.TYPE}§r§o ]\n§r§3§o[ ${alert.BY} ]`, 'textures/ui/worldsIcon.png')
           })
           
           form.button('§r§o[ §c§lExit§r§o ]\n§r§3§o> Here <','textures/ui/cancel.png')
           form.show(player).then(r=>{
               if(r.canceled) return
               
               if (r.selection == myAlerts.length) {
                   GeneralMenu(player)
                   return
               }
               
               let alertSelected = myAlerts[r.selection]
               let msgBody = ''
               let {team} = alertSelected
               if (alertSelected.team){

                   msgBody += `${team.color + team.name} | ${alertSelected.date} | ${team.owner}`
               }
               let b1 = alertSelected.TYPE === 'Inviate' ? '§2§lAcceptance': '§4§lDelete'
               let b2 = alertSelected.TYPE === 'Inviate' ? '§4§lRejected': "§0§lExit"
               let form1 = new MessageFormData()
                      .title(alertSelected.TYPE)
                      .body(`§o§f[§e!§f]§r - §4§l${alertSelected.MSG}` + `\n${msgBody}`)
                      .button1(`§r§o[ ${b1}§r§o ]`)
                      .button2(`§r§o[ ${b2}§r§o ]`)
                      .show(player).then(i=>{
                          if (
                              i.canceled ||
                              alertSelected.TYPE == 'Inviate' &&
                              i.selection == 1 ||
                              alertSelected.TYPE == 'PVP' &&
                              i.selection == 1
                              ) return
                          
                          if (i.selection == 0) {
                              if (alertSelected.TYPE !== 'Inviate'){
                                  alertsData.update(player.name, (value) => {
                                      let messageIndex = i.selection
                                      let newValue = value
                                      newValue.alerts.splice(messageIndex, 1)
                                      return newValue
                                  })
                                  createMsg(player, '§cMessage has been deleted.')
                              }else{
                                  hasJoined(player, team)
                              }
                              
                              if (i.selection == 1 && alertSelected.TYPE == 'Inviate') {
                                  alertsData.update(player.name, (value) => {
                                      let messageIndex = i.selection
                                      let newValue = value
                                      newValue.alerts.splice(messageIndex, 1)
                                      return newValue
                                  })
                                  createMsg(player, '§cMessage has been deleted')
                              }
                          }
                      })
           })
}

/*function SetAdmin (player) {
    let players = AllPlayers.all()
    let form = new ActionFormData()
          .title('§f§o[ Set Admin ]')
          .body("§o§f[§e!§f]§r - §b§lChose Player ?")
          
          currentPlayers.forEach(r => {
              form.button(`§r§o[ §b§l${r.name}§r§o ]\n§r§3§o> Here <`, 'textures/ui/worldsIcon.png')
          })
          form
             .show(player)
             .then(i=>{
                 if (i.canceled) return
                 if (
            currentPlayers[i.selection].hasTag('AdminOfWorld')){
                    player.onScreenDisplay.setActionBar(
                        `§fThis Player §b${currentPlayers[i.selection].name}§f He ownes §4Admin§f!!.`
                    )
                    return
                }
        currentPlayers[i.selection].addTag('AdminOfWorld')
        currentPlayers[i.selection].onScreenDisplay.setActionBar(
            `§4You have admin now by §b§l${player.name}`
        )
        player.onScreenDisplay('§f- §eDone!!§f. -')
             })
}*/

system.runInterval(() => {
    world.getPlayers().forEach((player) => {
        if (playerTeam.has(player.name)){
            let team = playerTeam.get(player.name)
            let team1 = teamsData.get(team.key)
            if (playersFlags[player.name]){
                let {teamKey, key} = playersFlags[player.name]
                let team_ = teamsData.get(key)
                player.nameTag = `${player.name} <§cteken ${team_.name} flag§r>`
            }
             else player.nameTag = `§r[ ${team1.color}${team1.name}§r ] ${player.name}`
        } else {
            player.nameTag = player.name
        }
     })
})

system.runInterval(()=>{
    world.getPlayers().forEach(player=>{
        if (playerTeam.has(player.name)){
            let team = playerTeam.get(player.name)
            let team1 = teamsData.get(team.key)
            let teamDt = teamDataBase.get(team.key)
            if (teamDt.level != 1) {
                let {x, y, z} = player.location
                let e = teamDt.entityLoc
                let playerDistance = Math.sqrt(Math.abs(x - e.x) ** 2 + Math.abs(y - e.y) ** 2 + Math.abs(z - e.z) ** 2)

                if (playerDistance <= teamDt.e_distance) {
                    if (team.selectedEffect) player.addEffect(team.selectedEffect, 20*8, { amplifier: teamDt.e_power, showParticles: false})
                }
            }
        }
    })
}, 20*5)

system.runInterval(() => {
    teamsData.all().forEach(team => {
        world.getPlayers().forEach(player => {
           let teamDt = teamDataBase.get(team.key)
           let e = teamDt.entityLoc
           let {x, y, z} = player.location
           let distance = Math.sqrt(Math.abs(x - e.x) ** 2 + Math.abs(y - e.y) ** 2 + Math.abs(z - e.z) ** 2)
           if (distance <= teamDt.e_distance && !teamDt.players.includes(player.name) && playerTeam.has(player.name)) {
               if (teamDt.selectedEnemyEffect) player.addEffect(teamDt.selectedEnemyEffect, 20 * 5, { amplifier: 2, showParticles: false})
           }
        })
    })
}, 20 * 7)


function TeamsList(player) {
    let form = new ActionFormData();
    let teams = teamsData.all();
    let teamPoints = teamDataBase.all();

    let teamsWithPoints = teams.map((team, index) => ({
        name: team.name,
        points: teamPoints[index].points
    }));

    teamsWithPoints.sort((a, b) => b.points - a.points);

    let resultString = teamsWithPoints.map((team, index) => 
        `§d§l§o${index + 1}§r - §b${team.name}§r : §o§e${team.points}`
    ).join("\n");
    if (resultString != ''){
        resultString+="\n\n"
    }

    form
     .title("§o§r[ Teams List ]")
     .body(resultString || "§c§lNo Teams in World!\n\n")
     .button("§r§o[ §4CLOSE§r§o ]\n§3> Here <", "textures/ui/cancel.png")
     .show(player)
     .then( r => {
         if (r.canceled) return;
         if (r.selection == 0) GeneralMenu(player);
     });
}
