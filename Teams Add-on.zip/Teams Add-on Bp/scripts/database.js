import { world } from "@minecraft/server"

export default class data {
    constructor (dynamicName, keysName=`${dynamicName}/keys`, cacheType=false) {
        this.name = dynamicName
        this.keysId = keysName
        if (cacheType) {
            world.setDynamicProperty(dynamicName, JSON.stringify({}))
            world.setDynamicProperty(keysName, JSON.stringify([]))
        }

        if (!world.getDynamicProperty(dynamicName) || !world.getDynamicProperty(keysName)) {
             world.setDynamicProperty(dynamicName, JSON.stringify({}))
             world.setDynamicProperty(keysName, JSON.stringify([]))
        }
    }

    all () {
            let alls = this.the_all()
            let result = [] 

            for (let key in alls) {
                result.push(alls[key])
            }

            return result
    }

    

    set (key, Value) {

        try {
            let the_all = this.the_all()
            let keys = this.the_allKeys()
            
            if (keys.includes(key)) this.delete(key)

            the_all[key] = Value 
            keys.push(key)

            world.setDynamicProperty(this.name, JSON.stringify(the_all))
            world.setDynamicProperty(this.keysId, JSON.stringify(keys))
        } catch (ERROR) {
            console.error("Error in Set:", ERROR)
        }
    }

    get (key) {

        try {
            let keys = this.the_allKeys()

            if (!keys.includes(key)) return undefined 

            let the_all = this.the_all() 
            let value = the_all[key] 

            if (value == undefined) return undefined 



            return value 
        } catch (ERROR) {
            console.error('error in get by key:', ERROR)
        }
    }

    delete (key) {
        try {
            let keys = this.the_allKeys()

            if (!keys.includes(key)) return;

            let the_all = this.the_all()
            let index = keys.indexOf(key)


            delete the_all[key]
            keys = keys.filter(r => r != key)

            world.setDynamicProperty(this.name, JSON.stringify(the_all)) 
            world.setDynamicProperty(this.keysId, JSON.stringify(keys)) 
        } catch (ERROR) {
            console.error('error in delete:', ERROR)
        }
    }

    has (key) {
        try {
            let keys = this.the_allKeys() 

            return keys.includes(key) 
        } catch (ERROR) { }
    }

    update (key, newValueCallback) {
        try {
            this.set(key, newValueCallback(this.get(key)))
        } catch (ERROR) {
            console.error(ERROR)
        }
    }

    /*correctValue (key, value) {
        let result
        
        if (typeof value != "object") return value
        
        if (value instanceof Array) {
            result = value
        } else {
            result = {...value, key}
        }

        return result
    }*/
    
    the_all(){
        return JSON.parse(world.getDynamicProperty(this.name))
    }
    the_allKeys(){
        return JSON.parse(world.getDynamicProperty(this.keysId))
    }
    
    size () {
        return this.all().length
    }
    clear(){
        world.setDynamicProperty(this.keysId, JSON.stringify([]))
        world.setDynamicProperty(this.name, JSON.stringify({}))
    }
}