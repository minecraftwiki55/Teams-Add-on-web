let sec = 1000;
export function getLevels() {
    let allLevels = {
        2: { points: [1000, 1500], time: sec * 60, awards: ["haste"], distance: 8, e_distance: 25, e_power: 2, enemyEffect: [] },
        3: { points: [1500, 2000], time: sec * 200, awards: ["fire_resistance"], distance: 15, e_distance: 50, e_power: 4, enemyEffect: [] },
        4: { points: [2000, 3000], time: sec * 300, awards: ["speed"], distance: 15, e_distance: 80, e_power: 6, enemyEffect: [] },
        5: { points: [3000, 4500], time: sec * 400, awards: ["resistance"], distance: 15, e_distance: 100, e_power: 8, enemyEffect: ["blindness", "hunger"] },
        6: { points: [4500, 6000], time: sec * 500, awards: ["strength"], distance: 20, e_distance: 120, e_power: 10, enemyEffect: [] },
        7: { points: [6000, 8000], time: sec * 600, awards: ["regeneration"], distance: 20, e_distance: 140, e_power: 10, enemyEffect: ["poison"] },
        8: { points: [8000, 10000], time: sec * 700, awards: ["haste"], distance: 25, e_distance: 160, e_power: 10, enemyEffect: [] },
        9: { points: [10000, 12000], time: sec * 800, awards: ["jump_boost"], distance: 25, e_distance: 180, e_power: 10, enemyEffect: ["slowness_effect"] },
        10: { points: [12000, 15000], time: sec * 900, awards: ["invisibility"], distance: 30, e_distance: 200, e_power: 10, enemyEffect: ["levitation"] },
        11: { points: [15000, 18000], time: sec * 1000, awards: [], distance: 30, e_distance: 220, e_power: 10, enemyEffect: [] },
        12: { points: [18000, 21000], time: sec * 1100, awards: [], distance: 35, e_distance: 240, e_power: 10, enemyEffect: ["wither"] },
        13: { points: [21000, 24000], time: sec * 1200, awards: [], distance: 35, e_distance: 260, e_power: 10, enemyEffect: [] },
        14: { points: [24000, 27000], time: sec * 1300, awards: [], distance: 40, e_distance: 280, e_power: 10, enemyEffect: [] },
        15: { points: [27000, 30000], time: sec * 1400, awards: [], distance: 40, e_distance: 300, e_power: 10, enemyEffect: [] },
        16: { points: [30000, 35000], time: sec * 1500, awards: [], distance: 45, e_distance: 320, e_power: 10, enemyEffect: [] },
        17: { points: [35000, 40000], time: sec * 1600, awards: [], distance: 45, e_distance: 340, e_power: 10, enemyEffect: [] },
        18: { points: [40000, 45000], time: sec * 1700, awards: [], distance: 50, e_distance: 360, e_power: 10, enemyEffect: [] },
        19: { points: [45000, 50000], time: sec * 1800, awards: [], distance: 50, e_distance: 380, e_power: 10, enemyEffect: [] },
        20: { points: [50000, 60000], time: sec * 1900, awards: [], distance: 55, e_distance: 400, e_power: 10, enemyEffect: [] }
    };
    return allLevels;
}
export function getProgressPercentage(elapsedTime, totalTime) {
    elapsedTime = Math.min(elapsedTime, totalTime);
    let progress = (elapsedTime / totalTime) * 100;
    return Math.floor(100 - progress);
}

